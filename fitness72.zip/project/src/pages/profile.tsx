import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import {
  Activity,
  Calendar,
  Edit,
  Goal,
  Ruler,
  Scale,
  Target,
  User,
} from 'lucide-react';
import { useEffect, useState } from 'react';

interface UserProfile {
  name: string;
  age: number;
  height: number;
  weight: number;
  goal: string;
  activityLevel: string;
  targetWeight: number;
}

const defaultProfile: UserProfile = {
  name: 'John Doe',
  age: 30,
  height: 175,
  weight: 70,
  goal: 'weight-loss',
  activityLevel: 'moderate',
  targetWeight: 65,
};

export function Profile() {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [editProfile, setEditProfile] = useState<UserProfile>(defaultProfile);
  const { toast } = useToast();

  useEffect(() => {
    const savedProfile = localStorage.getItem('userProfile');
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
      setEditProfile(JSON.parse(savedProfile));
    }
  }, []);

  const handleSaveProfile = () => {
    localStorage.setItem('userProfile', JSON.stringify(editProfile));
    setProfile(editProfile);
    toast({
      title: 'Profile Updated',
      description: 'Your profile has been successfully updated.',
    });
  };

  const stats = [
    {
      label: 'Workouts',
      value: '24',
      change: '+2',
    },
    {
      label: 'Active Days',
      value: '18',
      change: '+5',
    },
    {
      label: 'Goals Met',
      value: '8',
      change: '+1',
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Profile</h2>
          <p className="text-muted-foreground">
            Manage your profile and preferences.
          </p>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Edit className="mr-2 h-4 w-4" />
              Edit Profile
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Profile</DialogTitle>
              <DialogDescription>
                Update your personal information and preferences.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={editProfile.name}
                  onChange={(e) =>
                    setEditProfile({ ...editProfile, name: e.target.value })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  type="number"
                  value={editProfile.age}
                  onChange={(e) =>
                    setEditProfile({
                      ...editProfile,
                      age: parseInt(e.target.value),
                    })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="height">Height (cm)</Label>
                <Input
                  id="height"
                  type="number"
                  value={editProfile.height}
                  onChange={(e) =>
                    setEditProfile({
                      ...editProfile,
                      height: parseInt(e.target.value),
                    })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="weight">Weight (kg)</Label>
                <Input
                  id="weight"
                  type="number"
                  value={editProfile.weight}
                  onChange={(e) =>
                    setEditProfile({
                      ...editProfile,
                      weight: parseInt(e.target.value),
                    })
                  }
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="goal">Fitness Goal</Label>
                <Select
                  value={editProfile.goal}
                  onValueChange={(value) =>
                    setEditProfile({ ...editProfile, goal: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weight-loss">Weight Loss</SelectItem>
                    <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="endurance">
                      Endurance Training
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="activityLevel">Activity Level</Label>
                <Select
                  value={editProfile.activityLevel}
                  onValueChange={(value) =>
                    setEditProfile({ ...editProfile, activityLevel: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sedentary">Sedentary</SelectItem>
                    <SelectItem value="light">Lightly Active</SelectItem>
                    <SelectItem value="moderate">
                      Moderately Active
                    </SelectItem>
                    <SelectItem value="very-active">Very Active</SelectItem>
                    <SelectItem value="athlete">Athlete</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="targetWeight">Target Weight (kg)</Label>
                <Input
                  id="targetWeight"
                  type="number"
                  value={editProfile.targetWeight}
                  onChange={(e) =>
                    setEditProfile({
                      ...editProfile,
                      targetWeight: parseInt(e.target.value),
                    })
                  }
                />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleSaveProfile}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Age
              </span>
              <span>{profile.age} years</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Ruler className="h-4 w-4" />
                Height
              </span>
              <span>{profile.height} cm</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Scale className="h-4 w-4" />
                Weight
              </span>
              <span>{profile.weight} kg</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Goal className="h-4 w-4" />
              Fitness Goals
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Primary Goal
              </span>
              <span className="capitalize">
                {profile.goal.replace('-', ' ')}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activity Level
              </span>
              <span className="capitalize">
                {profile.activityLevel.replace('-', ' ')}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Scale className="h-4 w-4" />
                Target Weight
              </span>
              <span>{profile.targetWeight} kg</span>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Monthly Stats</CardTitle>
            <CardDescription>Your progress this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="flex items-center justify-between"
                >
                  <span>{stat.label}</span>
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{stat.value}</span>
                    <span className="text-sm text-green-500">
                      {stat.change}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}