import { Button } from '@/components/ui/button';
import {
  ActivitySquare,
  Apple,
  LayoutDashboard,
  Moon,
  Sun,
  User,
} from 'lucide-react';
import { useTheme } from 'next-themes';

interface MainLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function MainLayout({
  children,
  currentPage,
  onPageChange,
}: MainLayoutProps) {
  const { theme, setTheme } = useTheme();

  const navItems = [
    {
      label: 'Dashboard',
      value: 'dashboard',
      icon: LayoutDashboard,
    },
    {
      label: 'Workouts',
      value: 'workouts',
      icon: ActivitySquare,
    },
    {
      label: 'Nutrition',
      value: 'nutrition',
      icon: Apple,
    },
    {
      label: 'Profile',
      value: 'profile',
      icon: User,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="fixed top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center px-4">
          <div className="flex items-center gap-2 font-semibold">
            <ActivitySquare className="h-6 w-6" />
            <span>FitTrack</span>
          </div>
          <div className="flex flex-1 items-center justify-center space-x-4">
            {navItems.map((item) => (
              <Button
                key={item.value}
                variant={currentPage === item.value ? 'default' : 'ghost'}
                className="flex items-center gap-2"
                onClick={() => onPageChange(item.value)}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Button>
            ))}
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="ml-auto"
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </nav>
      <main className="container mx-auto mt-20 px-4 pb-8">{children}</main>
    </div>
  );
}