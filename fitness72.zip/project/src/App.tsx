import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/sonner';
import { MainLayout } from '@/layouts/main-layout';
import { Dashboard } from '@/pages/dashboard';
import { Nutrition } from '@/pages/nutrition';
import { Profile } from '@/pages/profile';
import { Workouts } from '@/pages/workouts';
import { useState } from 'react';

type Page = 'dashboard' | 'workouts' | 'nutrition' | 'profile';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'workouts':
        return <Workouts />;
      case 'nutrition':
        return <Nutrition />;
      case 'profile':
        return <Profile />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <ThemeProvider defaultTheme="light" storageKey="health-fitness-theme">
      <MainLayout currentPage={currentPage} onPageChange={setCurrentPage}>
        {renderPage()}
      </MainLayout>
      <Toaster />
    </ThemeProvider>
  );
}

export default App;